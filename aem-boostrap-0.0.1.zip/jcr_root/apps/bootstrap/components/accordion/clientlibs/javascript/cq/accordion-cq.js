(function(){

    $(document).ready(function(){
        console.log("Accordion client lib");
    });
})();
